# INFO

This repo links to my Instructable (https://www.instructables.com/id/LCD-IP-Clock/)

The demo_lcd.py program will print some text out on the LCD if it is wired up correctly.

The demo_clock.py program will print the currents time on the LCD plus some funny text.

The demo_scrolling_text.py program will print some text that will scroll along the screen.

The program clock-ip.py will print some text of your choice along with the time, ip address and hostname.
